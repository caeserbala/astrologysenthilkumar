var webfonts = require('./')

webfonts.add({
    'Ropa Sans': 400
  , 'Source Sans Pro': true
})
